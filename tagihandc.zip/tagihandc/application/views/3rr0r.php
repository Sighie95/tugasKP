<!DOCTYPE html>
<html lang="en">
<head>
  <title>404 Not Found Slur</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo base_url('bootstrap/') ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url('bootstrap/') ?>css/footer.css"> 
  <link rel="stylesheet" href="<?php echo base_url('font-awesome/') ?>css/font-awesome.css" type="text/css">   
  <link rel="stylesheet" href="<?php echo base_url('font-awesome/') ?>css/brands.css" type="text/css"> 
  <link rel="stylesheet" href="<?php echo base_url('font-awesome/') ?>css/solid.css" type="text/css"> 
  <link rel="stylesheet" href="<?php echo base_url('bootstrap/') ?>css/garis_new.css" type="text/css">       
  <script src="<?php echo base_url('bootstrap/') ?>js/jquery.min.js"></script>
  <script src="<?php echo base_url('bootstrap/') ?>js/popper.min.js"></script>
  <script src="<?php echo base_url('bootstrap/') ?>js/bootstrap.min.js"></script>
    <style>
  body {
   background-image: url('<?php echo base_url('bootstrap/') ?>Bg.jpg');
   background-position: center;
   background-size: cover;
   background-repeat: no-repeat;
   min-height: 100vh;
   font-family: 'Roboto', sans-serif;
}</style>
</head>
<body>
  <div class="container">
<center>
<img src="<?php echo base_url('bootstrap/') ?>40404.png" class="rounded" alt="Logo" style="width:850px;"></a>
</center>
<center><a href="<?php echo base_url() ?>" type="button" class="btn btn-outline-warning">Beranda</a></center>
<b><center><br><span style="color: #fff;"><p class="footer-company-name">TagihanDC &copy; 2019</span><br> 
      Made with <span style="color: #ff0000;">❤</span> for a better web.</p></center></b>
</div>
</body>
</html>