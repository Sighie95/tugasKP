<div class="container">
	<br>
  <center><h4 class="section-text"><span><b><i>"Solusi Pembayaran Tagihanmu"</i></b></span></h4></center>
  </div><br>
<footer class="footer-distributed">

	<div class="footer-left">                 
		<h3>Tagihan<span style="color: #dc3545;">DC</span></h3><br>
		<p class="footer-company-name">Dieng Cyber &copy; 2017<br> 
			Made with <span style="color: #ff0000;">❤</span> for a better web.</p>
	</div>             
	<div class="footer-center"><div>                     
		<i class="fa fa-map-marker"></i>
		<p><span>Jl S Parman, </span> Semagung Wonosobo 56311, Indonesia</p>                 
	</div>                 
	<div>                     
		<i class="fa fa-mobile-alt"></i>
		<p>085729670954</p>                 
	</div>                 
	<div>                     
		<i class="fa fa-envelope"></i>
		<p><a href="mailto:support@company.com"><span style="color: #dc3545;">support@tagihandc.com</span></a></p>                 
	</div>
	</div>             
	<div class="footer-right">                 
		<p class="footer-company-about">
			<span>Tentang Kami</span>                     
		Lorem ipsum dolor sit amet, consectateur adispicing elit. Fusce euismod convallis velit, eu auctor lacus vehicula sit amet. lorem</p>                 
		<div class="footer-icons">                     
			<a href="//https//www.facebook.com"><i class="fab fa-facebook-f"></i></a>                     
			<a href="https://twitter.com"><i class="fab fa-twitter"></i></a>                     
			<a href="https://plus.google.com"><i class="fab fa-google"></i></a>                     
			<a href="https://github.com"><i class="fab fa-github"></i></a>                 
		</div>             
	</div>         
</footer>