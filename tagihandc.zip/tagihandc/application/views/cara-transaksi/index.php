<!DOCTYPE html>
<html lang="en">
<head>
  <title>Cara Transaksi | TagihanDC</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo base_url('bootstrap/') ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url('bootstrap/') ?>css/footer.css"> 
  <link rel="stylesheet" href="<?php echo base_url('font-awesome/') ?>css/font-awesome.css" type="text/css">   
  <link rel="stylesheet" href="<?php echo base_url('font-awesome/') ?>css/brands.css" type="text/css"> 
  <link rel="stylesheet" href="<?php echo base_url('font-awesome/') ?>css/solid.css" type="text/css"> 
  <link rel="stylesheet" href="<?php echo base_url('bootstrap/') ?>css/garis_new.css" type="text/css">       
  <script src="<?php echo base_url('bootstrap/') ?>js/jquery.min.js"></script>
  <script src="<?php echo base_url('bootstrap/') ?>js/popper.min.js"></script>
  <script src="<?php echo base_url('bootstrap/') ?>js/bootstrap.min.js"></script>
</head>
<body>
<div class="jumbotron jumbotron-fluid">
  <div class="container"><center>
    <img src="<?php echo base_url('bootstrap/') ?>transaksi2.png" class="rounded" alt="Logo" style="width:700px;"></a></center><br><br><hr>
    <center><h2><b>Jalur Transaksi</b></h2></center><br>
    <center>Kami memiliki beberapa jalur untuk melakukan transaksi.</center><hr width="450px"><br><br><br><br>
    <div class="row">
    <div class="col-sm">
    <center><img src="<?php echo base_url('bootstrap/') ?>internet.png" class="rounded" alt="Logo" style="width:50px;"></center><br>
    <center><b>Transaksi via Website</b></center>
    <center><p>Jalur transaksi kami saat ini adalah melalui website yang dapat di akses melalui perangkat komputer atau perangkat smartphone anda.</p></center>
  </div>
  <div class="col-sm">
   <center><img src="<?php echo base_url('bootstrap/') ?>telegram.png" class="rounded" alt="Logo" style="width:50px;"></center><br>
   <center><b>Transaksi via Messenger</b></center>
    <center><p>Kami juga menyediakan jalur transaksi melalui aplikasi messanger seperti Telegram, WhatsApp.</p></center>
  </div>
</div>
</div><br><br>
</div>
</body>
</html>